namespace PaymentApiApp.Configuration{

    public class JwtConfig{
        public string Secret {get; set;}
    }
}