using PaymentApiApp.Configuration;
namespace PaymentApiApp.Models.DTOs.Responses
{
    public class RegistrationResponse : AuthResult
    {
        
    }
}