Assignment no.2

Farhan Eka Fajri
FSDO003ONL011
Execute per baris fungsi tabel

https://github.com/farhan-eka-fajri/ocbc-c--batch3/tree/main/sesi6/assignment2