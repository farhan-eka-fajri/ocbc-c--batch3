Assignment no. 3
Nama 				: Farhan Eka Fajri
No.Peserta 			: FSDO003ONL011
Link Github			: https://github.com/farhan-eka-fajri/ocbc-c--batch3/tree/main/sesi10/assignment3/MovieApi
Cara Penggunaan Aplikasi:
1. Buka folder EtasaKarenisa_007_Assignment3 di IDE.
2. Nyalakan XAMPP Apache dan MySQL.
3. Run Code dengan dotnet run atau dotnet run watch.
4. Jika index.html tidak otomatis terbuka di default browser, ketik https://localhost:5001/swagger/index.html di browser.
6. Klik Try it out pada swagger pada api yang diinginkan.
7. Pada notes JSON, ganti nilai dari masing-masing parameter
8. Klik Execute.
9. Jika berhasil maka response code berupa 2** serta menunjukkan response data.
10. Copy URL dari swagger dan paste pada Postman jika ingin dicoba.